
package prueba;

import java.util.Scanner;

public class Prueba {
    
    public static void main(String[] args) {
       
        Scanner sc = new Scanner(System.in);
        int opcion = 0;
        
        do {
            System.out.println("***** MENÚ *****");
            System.out.println("1. Mayor de edad");
            System.out.println("2. Par positivo");
            System.out.println("3. Capicúa");
            System.out.println("4. Tributo");
            System.out.println("5. Salir");
            System.out.print("Ingresa una opción: ");
            opcion = sc.nextInt();
            
            switch(opcion) {
                case 1:
                    System.out.print("Ingresa tu edad: ");
                    int edad = sc.nextInt();
                    
                    if(edad >= 18) {
                        System.out.println("Eres mayor de edad.");
                    } else {
                        System.out.println("Eres menor de edad.");
                    }
                    break;
                    
                case 2:
                    System.out.print("Ingresa un número: ");
                    int numero = sc.nextInt();
                    
                    if(numero > 0 && numero % 2 == 0) {
                        System.out.println("El número " + numero + " es par positivo.");
                    } else {
                        System.out.println("El número " + numero + " no es par positivo.");
                    }
                    break;
                    
                case 3:
                    System.out.print("Ingresa un número de tres cifras: ");
                    int numCapicua = sc.nextInt();
                    
                    int primeraCifra = numCapicua / 100;
                    int terceraCifra = numCapicua % 10;
                    
                    if(primeraCifra == terceraCifra) {
                        System.out.println("El número " + numCapicua + " es capicúa.");
                    } else {
                        System.out.println("El número " + numCapicua + " no es capicúa.");
                    }
                    break;
                    
                case 4:
                    System.out.print("Ingresa tu edad: ");
                    int edadTributo = sc.nextInt();
                    
                    System.out.print("Ingresa tus ingresos mensuales: ");
                    double ingresos = sc.nextDouble();
                    
                    if(edadTributo > 16 && ingresos >= 1000) {
                        System.out.println("Tienes que tributar.");
                    } else {
                        System.out.println("No tienes que tributar.");
                    }
                    break;
                    
                case 5:
                    System.out.println("¡Gracias por usar el programa!");
                    break;
                    
                default:
                    System.out.println("Opción no válida. Ingresa otra opción.");
                    break;
            }
            
            System.out.println(); // Salto de línea para separar cada opción
        } while(opcion != 5);
        
        sc.close();
    }
}

    
    

